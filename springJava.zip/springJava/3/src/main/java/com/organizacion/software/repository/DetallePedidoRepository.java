package com.organizacion.software.repository;

import com.organizacion.software.model.DetallePedido;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetallePedidoRepository extends JpaRepository<DetallePedido, Long>{
}

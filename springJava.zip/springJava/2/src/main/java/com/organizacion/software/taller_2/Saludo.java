package com.organizacion.software.t2;

public record Saludo(long id, String content) {
}
